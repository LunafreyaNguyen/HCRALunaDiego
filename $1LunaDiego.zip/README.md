# HCRALunaDiego
HCRA project repository- Lunafreya and Diego

Resampling
Line 160 - Resample

Scaling
Line 191 - ScaleToSquare

Translation
Line 204 TranslateToOrigin

Rotation 
Line 256 - RotateBy

