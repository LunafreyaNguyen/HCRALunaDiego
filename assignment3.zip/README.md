# HCRALunaDiego
HCRA project repository- Lunafreya and Diego

Resampling
Line 160 - Resample

Scaling
Line 191 - ScaleToSquare

Translation
Line 204 TranslateToOrigin

Rotation 
Line 256 - RotateBy


--PART 3--

Read in Dataset - Line - 388

    XML user input files are read into program thorugh the xmllog[]


Connect to Recognizer - Line 482 using offlineRecognize function

    offlineRecognize - Line 508

Loop Over Dataset (Random100) - Line 460

    In this step we loop through the entire array and do the recognition tests

Output the Result - Line 544

    Output the information necessary about the offline recognition tests int oa .csv file
